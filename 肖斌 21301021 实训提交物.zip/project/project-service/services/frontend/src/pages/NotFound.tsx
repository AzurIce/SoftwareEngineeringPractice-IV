import { Component } from "solid-js"

const NotFound: Component = () => {
  return <>
    404 Not Found
  </>
}

export default NotFound